.. _qiskit-aqua-operators:

.. automodule:: qiskit.aqua.operators
   :no-members:
   :no-inherited-members:
   :no-special-members:
