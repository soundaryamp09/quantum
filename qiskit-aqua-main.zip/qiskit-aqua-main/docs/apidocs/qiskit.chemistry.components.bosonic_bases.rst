.. _qiskit-chemistry-components-bosonic_bases:

.. automodule:: qiskit.chemistry.components.bosonic_bases
   :no-members:
   :no-inherited-members:
   :no-special-members:
