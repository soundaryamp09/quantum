.. _qiskit-finance-applications-ising:

.. automodule:: qiskit.finance.applications.ising
   :no-members:
   :no-inherited-members:
   :no-special-members:
