.. _qiskit-ml-datasets:

.. automodule:: qiskit.ml.datasets
   :no-members:
   :no-inherited-members:
   :no-special-members:
