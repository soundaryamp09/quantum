.. _qiskit-aqua-operators-gradients:

.. automodule:: qiskit.aqua.operators.gradients
   :no-members:
   :no-inherited-members:
   :no-special-members:
