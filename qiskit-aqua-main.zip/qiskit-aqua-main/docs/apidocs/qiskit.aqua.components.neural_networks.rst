.. _qiskit-aqua-components-neural_networks:

.. automodule:: qiskit.aqua.components.neural_networks
   :no-members:
   :no-inherited-members:
   :no-special-members:
