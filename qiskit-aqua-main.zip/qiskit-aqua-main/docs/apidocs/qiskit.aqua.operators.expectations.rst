.. _qiskit-aqua-operators-expectations:

.. automodule:: qiskit.aqua.operators.expectations
   :no-members:
   :no-inherited-members:
   :no-special-members:
