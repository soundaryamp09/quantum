.. _qiskit-aqua-algorithms:

.. automodule:: qiskit.aqua.algorithms
   :no-members:
   :no-inherited-members:
   :no-special-members:
