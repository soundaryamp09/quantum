.. _qiskit-aqua-components-oracles:

.. automodule:: qiskit.aqua.components.oracles
   :no-members:
   :no-inherited-members:
   :no-special-members:
