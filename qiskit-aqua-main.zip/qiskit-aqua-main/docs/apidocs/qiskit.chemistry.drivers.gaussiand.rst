.. _qiskit-chemistry-drivers-gaussiand:

.. automodule:: qiskit.chemistry.drivers.gaussiand
   :no-members:
   :no-inherited-members:
   :no-special-members:
