.. _qiskit-aqua-operators-legacy:

.. automodule:: qiskit.aqua.operators.legacy
   :no-members:
   :no-inherited-members:
   :no-special-members:
