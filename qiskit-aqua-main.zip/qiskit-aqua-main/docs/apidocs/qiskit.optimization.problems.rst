.. _qiskit-optimization-problems:

.. automodule:: qiskit.optimization.problems
   :no-members:
   :no-inherited-members:
   :no-special-members:
