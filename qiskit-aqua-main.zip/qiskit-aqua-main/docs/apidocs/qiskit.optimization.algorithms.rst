.. _qiskit-optimization-algorithms:

.. automodule:: qiskit.optimization.algorithms
   :no-members:
   :no-inherited-members:
   :no-special-members:
