.. _qiskit-optimization:

.. automodule:: qiskit.optimization
   :no-members:
   :no-inherited-members:
   :no-special-members:
