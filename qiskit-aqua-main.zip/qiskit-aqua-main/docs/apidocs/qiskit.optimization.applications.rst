.. _qiskit-optimization-applications:

.. automodule:: qiskit.optimization.applications
   :no-members:
   :no-inherited-members:
   :no-special-members:
