.. _qiskit-aqua-components-optimizers-nlopts:

.. automodule:: qiskit.aqua.components.optimizers.nlopts
   :no-members:
   :no-inherited-members:
   :no-special-members:
