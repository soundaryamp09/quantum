.. _qiskit-aqua-operators-list_ops:

.. automodule:: qiskit.aqua.operators.list_ops
   :no-members:
   :no-inherited-members:
   :no-special-members:
