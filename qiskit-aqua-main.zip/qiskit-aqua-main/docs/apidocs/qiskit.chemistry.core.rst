.. _qiskit-chemistry-core:

.. automodule:: qiskit.chemistry.core
   :no-members:
   :no-inherited-members:
   :no-special-members:
