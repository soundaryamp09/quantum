.. _qiskit-aqua-operators-state_fns:

.. automodule:: qiskit.aqua.operators.state_fns
   :no-members:
   :no-inherited-members:
   :no-special-members:
