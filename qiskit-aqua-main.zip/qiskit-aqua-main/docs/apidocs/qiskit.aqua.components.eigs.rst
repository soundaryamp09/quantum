.. _qiskit-aqua-components-eigs:

.. automodule:: qiskit.aqua.components.eigs
   :no-members:
   :no-inherited-members:
   :no-special-members:
