.. _qiskit-aqua:

.. automodule:: qiskit.aqua
   :no-members:
   :no-inherited-members:
   :no-special-members:
