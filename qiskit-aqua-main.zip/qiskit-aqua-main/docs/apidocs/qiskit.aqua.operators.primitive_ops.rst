.. _qiskit-aqua-operators-primitive_ops:

.. automodule:: qiskit.aqua.operators.primitive_ops
   :no-members:
   :no-inherited-members:
   :no-special-members:
