.. _qiskit-finance-applications:

.. automodule:: qiskit.finance.applications
   :no-members:
   :no-inherited-members:
   :no-special-members:
