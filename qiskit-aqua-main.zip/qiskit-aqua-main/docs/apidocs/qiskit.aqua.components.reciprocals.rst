.. _qiskit-aqua-components-reciprocals:

.. automodule:: qiskit.aqua.components.reciprocals
   :no-members:
   :no-inherited-members:
   :no-special-members:
