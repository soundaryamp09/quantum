.. _qiskit-optimization-applications-ising:

.. automodule:: qiskit.optimization.applications.ising
   :no-members:
   :no-inherited-members:
   :no-special-members:
