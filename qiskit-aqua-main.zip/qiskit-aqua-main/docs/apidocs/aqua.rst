======================================
Qiskit Aqua API Reference (Deprecated)
======================================

.. toctree::
    :maxdepth: 2

    qiskit_aqua
    qiskit_chemistry
    qiskit_finance
    qiskit_ml
    qiskit_optimization
