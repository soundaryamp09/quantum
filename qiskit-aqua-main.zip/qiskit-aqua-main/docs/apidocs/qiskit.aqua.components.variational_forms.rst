.. _qiskit-aqua-components-variational_forms:

.. automodule:: qiskit.aqua.components.variational_forms
   :no-members:
   :no-inherited-members:
   :no-special-members:
