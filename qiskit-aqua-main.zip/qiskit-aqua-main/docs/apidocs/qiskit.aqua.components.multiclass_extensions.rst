.. _qiskit-aqua-components-multiclass_extensions:

.. automodule:: qiskit.aqua.components.multiclass_extensions
   :no-members:
   :no-inherited-members:
   :no-special-members:
